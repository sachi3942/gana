# බෙදෙනවද් — Android App (Live Pointer Mode)

## දැන් app එකේ තියෙන්නෙ

1. **සාමාන්‍ය ඇප් එක** — screen එකේ paper එකක් වගේ ඉලක්කම් float වෙනවා, ඇඟිල්ල ඇදගෙන ගියාම කොල/රතු වෙනවා.
2. **Live Pointer 🎯** — *ඕන app එකක් උඩින්ම* (photo viewer, PDF reader, browser — ඕනම එකක්) real-time screen capture එකෙන් ක්‍රියාත්මක වෙන pointer + status box එකක්. Pointer එක ඉලක්කමක් මතට ගෙනියද්දී, status box එක ඒ ඉලක්කම තෝරාගත්ත divisor එකෙන් බෙදෙනවනම් **කොල**, නැත්නම් **රතු** වෙනවා — ක්‍ෂණිකව.

## Live Pointer එක වැඩ කරන විදිය (technical)

Android එකේ security design එක අනුව, එක app එකකට තව app එකක screen එකේ පේන දේ බලාගන්න පුළුවන් **screen capture (MediaProjection) permission** එකෙන් විතරයි. ඒ නිසා:

- App එක open කරලා **"Live Pointer ආරම්භ කරන්න 🎯"** ඔබද්දී, phone එකෙන් step 3ක් අහයි:
  1. **Display over other apps** — allow කරන්න
  2. **Notifications** (Android 13+) — allow කරන්න
  3. **Start recording / casting this screen?** — "Start now" ඔබන්න
- ඒ තුනම allow කලාට පස්සෙ, screen එකේ **status bar එකේ permanent icon එකක්** පේනවා "screen being recorded" කියලා — මේක Android එකේම rule එකක්, කිසිම app එකකට අයින් කරන්න බෑ (ඔබේ privacy protect කරන්නම).
- Screen එකේ පොඩි control panel එකක් (divisor + status box + ✕) සහ වෙනම draggable **pointer ring** එකක් float වෙනවා. Pointer එක ඇඳගෙන යනකොට, app එක screen එකේ ඒ ලඟින් තියෙන ප්‍රදේශයම capture කරලා, ඒකේ ඉලක්කම් on-device text recognition එකෙන් කියවලා, pointer එකට හරියටම යටින් තියෙන ඉලක්කම බලාගන්නවා.
- ~250ms වතාවක් වගේ update වෙනවා (fully continuous 60fps නෙවෙයි — battery/CPU ඉතුරු කරගන්න), ඒත් practical විදිහට "live" වගේම දැනෙනවා.

## GitHub එකට දාලා APK එක හදාගන්නා විදිය

1. [github.com](https://github.com) එකේ අලුත් repository එකක් හදන්න.
2. මේ zip එක unzip කරලා, **`.github` folder එකත් ඇතුළුව** සියල්ල push කරන්න:
   ```
   git init
   git add .
   git commit -m "first commit"
   git branch -M main
   git remote add origin https://github.com/<username>/<repo>.git
   git push -u origin main
   ```
3. **Actions** tab එකේ "Build APK" workflow එක run වෙනකන් ඉන්න (විනාඩි 4-7).
4. **Artifacts** කොටසේ `gana-app-debug-apk` download කරලා, `app-debug.apk` phone එකට copy කරන්න, install කරන්න (unknown sources allow කරන්න ඕන වෙයි).

## දැනගන්න ඕන දේවල් (limitations)

- **minSdk 29 (Android 10+)** — ඔබේ Android 14 phone එකට ගැලපෙනවා, ඒත් ඊට වඩා පරණ phone වල install වෙන්නෙ නෑ.
- Screen recording indicator (status bar icon) එක **අනිවාර්යයෙන්ම** පේනවා — Android එකේම rule එකක්.
- Text recognition එක photo/PDF එකේ font/handwriting clarity එක මත depend වෙනවා — clear print ඉලක්කම් වලට හොඳම වැඩ කරනවා.
- Battery optimization එකෙන් Android එකෙන්ම service එක kill කරන්න පුළුවන් — ඒවුනොත් app එකට ආපහු ගිහින් "Live Pointer ආරම්භ කරන්න" ආයෙත් ඔබන්න.
- මම මේ code එක තමන්ම compile/run කරලා real phone එකක test කරලා නෑ (build environment එකේ Android SDK/emulator නෑ) — MediaProjection/ImageReader/ML Kit සම්බන්ධ standard, well-documented patterns වලින් හැදුවේ, ඒත් GitHub Actions log එකේ error එකක් හෝ phone එකේ crash එකක් ආවොත් copy කරලා/screenshot එකක් එවලා පෙන්නන්න — මම fix කරන්නම්.

## Local machine එකේ (Android Studio තියෙනවා නම්)

Folder එකම Android Studio එකෙන් **"Open"** කරලා `Run` ▶️ එකෙන් direct run කරන්නත් පුළුවන්.
