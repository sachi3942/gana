package com.lk.ganaapp;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.nio.ByteBuffer;

public class ScreenPointerService extends Service {

    private static final String CHANNEL_ID = "gana_live_channel";
    private static final int NOTIF_ID = 501;
    private static final int[] DIVISORS = {2, 3, 4, 5, 6, 10};
    private static final long TICK_MS = 260;

    private WindowManager windowManager;
    private View controlPanel;
    private View pointerView;
    private WindowManager.LayoutParams controlParams;
    private WindowManager.LayoutParams pointerParams;

    private TextView statusBox;
    private LinearLayout divisorRow;

    private int divisor = 2;
    private boolean started = false;
    private boolean dragging = false;

    private MediaProjectionManager projectionManager;
    private MediaProjection mediaProjection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private int screenWidth, screenHeight, screenDensity;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            checkPointer();
            if (dragging) handler.postDelayed(this, TICK_MS);
        }
    };

    private static class NumberBox {
        final int value;

        NumberBox(int v) {
            value = v;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (!started) {
            started = true;
            createNotificationChannel();
            Notification notification = buildNotification();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIF_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIF_ID, notification);
            }

            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);

            int resultCode = intent != null ? intent.getIntExtra("resultCode", 0) : 0;
            Intent data = intent != null ? intent.getParcelableExtra("data") : null;

            if (data == null) {
                Toast.makeText(this, "Screen capture permission නෑ", Toast.LENGTH_SHORT).show();
                stopSelf();
                return START_NOT_STICKY;
            }

            mediaProjection = projectionManager.getMediaProjection(resultCode, data);
            mediaProjection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    stopSelf();
                }
            }, handler);

            setupVirtualDisplay();
            buildOverlays();
        }
        return START_NOT_STICKY;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Gana Live", NotificationManager.IMPORTANCE_LOW);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("බෙදෙනවද් ක්‍රියාත්මකයි")
                .setContentText("Pointer එක ඉලක්කමක් මත තියන්න")
                .setSmallIcon(R.drawable.ic_stat_notify)
                .setOngoing(true)
                .build();
    }

    private void setupVirtualDisplay() {
        DisplayMetrics metrics = getResources().getDisplayMetrics();
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        screenDensity = metrics.densityDpi;

        imageReader = ImageReader.newInstance(screenWidth, screenHeight, PixelFormat.RGBA_8888, 2);
        virtualDisplay = mediaProjection.createVirtualDisplay(
                "GanaLiveCapture", screenWidth, screenHeight, screenDensity,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader.getSurface(), null, handler);
    }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private void buildOverlays() {
        int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;

        controlPanel = LayoutInflater.from(this).inflate(R.layout.control_panel, null);
        statusBox = controlPanel.findViewById(R.id.statusBox);
        divisorRow = controlPanel.findViewById(R.id.divisorRow);
        TextView closeBtn = controlPanel.findViewById(R.id.closeBtn);
        View headerBar = controlPanel.findViewById(R.id.headerBar);
        buildDivisorButtons();
        closeBtn.setOnClickListener(v -> stopSelf());

        controlParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        controlParams.gravity = Gravity.TOP | Gravity.START;
        controlParams.x = dp(16);
        controlParams.y = dp(60);
        setupDrag(headerBar, controlParams, controlPanel);
        windowManager.addView(controlPanel, controlParams);

        pointerView = LayoutInflater.from(this).inflate(R.layout.pointer_view, null);
        pointerParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        pointerParams.gravity = Gravity.TOP | Gravity.START;
        pointerParams.x = screenWidth / 2 - dp(23);
        pointerParams.y = screenHeight / 2 - dp(23);
        windowManager.addView(pointerView, pointerParams);

        pointerView.setOnTouchListener(new View.OnTouchListener() {
            float touchStartRawX, touchStartRawY;
            int startX, startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        touchStartRawX = event.getRawX();
                        touchStartRawY = event.getRawY();
                        startX = pointerParams.x;
                        startY = pointerParams.y;
                        dragging = true;
                        handler.post(ticker);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchStartRawX);
                        int dy = (int) (event.getRawY() - touchStartRawY);
                        pointerParams.x = startX + dx;
                        pointerParams.y = startY + dy;
                        windowManager.updateViewLayout(pointerView, pointerParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        checkPointer();
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void buildDivisorButtons() {
        divisorRow.removeAllViews();
        for (int d : DIVISORS) {
            TextView btn = new TextView(this);
            btn.setText(String.valueOf(d));
            btn.setTextColor(d == divisor ? 0xFFFFFFFF : 0xFF243B53);
            btn.setTextSize(13);
            btn.setGravity(Gravity.CENTER);
            btn.setBackgroundResource(d == divisor ? R.drawable.divisor_btn_active_bg : R.drawable.divisor_btn_bg);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
            lp.setMargins(dp(2), 0, dp(2), 0);
            btn.setLayoutParams(lp);
            btn.setOnClickListener(v -> {
                divisor = d;
                buildDivisorButtons();
                checkPointer();
            });
            divisorRow.addView(btn);
        }
    }

    private void setupDrag(View handle, WindowManager.LayoutParams params, View window) {
        handle.setOnTouchListener(new View.OnTouchListener() {
            float touchStartRawX, touchStartRawY;
            int startX, startY;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        touchStartRawX = event.getRawX();
                        touchStartRawY = event.getRawY();
                        startX = params.x;
                        startY = params.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        int dx = (int) (event.getRawX() - touchStartRawX);
                        int dy = (int) (event.getRawY() - touchStartRawY);
                        params.x = startX + dx;
                        params.y = startY + dy;
                        windowManager.updateViewLayout(window, params);
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void checkPointer() {
        if (imageReader == null || pointerParams == null) return;
        int centerX = pointerParams.x + dp(23);
        int centerY = pointerParams.y + dp(23);

        Bitmap full = captureFrame();
        if (full == null) return;

        int cropHalf = dp(70);
        int cropSize = cropHalf * 2;
        if (full.getWidth() < cropSize || full.getHeight() < cropSize) return;

        int left = Math.max(0, Math.min(centerX - cropHalf, full.getWidth() - cropSize));
        int top = Math.max(0, Math.min(centerY - cropHalf, full.getHeight() - cropSize));
        int localX = centerX - left;
        int localY = centerY - top;

        Bitmap crop;
        try {
            crop = Bitmap.createBitmap(full, left, top, cropSize, cropSize);
        } catch (Exception e) {
            return;
        }

        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        InputImage image = InputImage.fromBitmap(crop, 0);
        recognizer.process(image).addOnSuccessListener(visionText -> {
            NumberBox match = findMatch(visionText, localX, localY);
            updateStatusBox(match);
        });
    }

    private NumberBox findMatch(Text visionText, int localX, int localY) {
        for (Text.TextBlock block : visionText.getTextBlocks()) {
            for (Text.Line line : block.getLines()) {
                for (Text.Element element : line.getElements()) {
                    Rect r = element.getBoundingBox();
                    if (r != null && r.contains(localX, localY)) {
                        String digits = element.getText().replaceAll("[^0-9]", "");
                        if (!digits.isEmpty()) {
                            try {
                                return new NumberBox(Integer.parseInt(digits));
                            } catch (NumberFormatException ignored) {
                            }
                        }
                    }
                }
            }
        }
        return null;
    }

    private Bitmap captureFrame() {
        Image image = null;
        try {
            image = imageReader.acquireLatestImage();
            if (image == null) return null;
            Image.Plane[] planes = image.getPlanes();
            ByteBuffer buffer = planes[0].getBuffer();
            int pixelStride = planes[0].getPixelStride();
            int rowStride = planes[0].getRowStride();
            int rowPadding = rowStride - pixelStride * screenWidth;
            Bitmap bitmap = Bitmap.createBitmap(
                    screenWidth + rowPadding / pixelStride, screenHeight, Bitmap.Config.ARGB_8888);
            bitmap.copyPixelsFromBuffer(buffer);
            if (rowPadding != 0) {
                bitmap = Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight);
            }
            return bitmap;
        } catch (Exception e) {
            return null;
        } finally {
            if (image != null) image.close();
        }
    }

    private void updateStatusBox(NumberBox match) {
        if (statusBox == null) return;
        if (match == null) {
            statusBox.setBackgroundResource(R.drawable.status_neutral_bg);
            statusBox.setText("?");
            return;
        }
        boolean divisible = match.value % divisor == 0;
        statusBox.setBackgroundResource(divisible ? R.drawable.status_yes_bg : R.drawable.status_no_bg);
        statusBox.setText(divisible ? "✅" : "❌");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(ticker);
        if (windowManager != null) {
            try {
                if (controlPanel != null) windowManager.removeView(controlPanel);
            } catch (Exception ignored) {
            }
            try {
                if (pointerView != null) windowManager.removeView(pointerView);
            } catch (Exception ignored) {
            }
        }
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null) imageReader.close();
        if (mediaProjection != null) mediaProjection.stop();
        started = false;
    }
}
